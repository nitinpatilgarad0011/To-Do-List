
const express = require('express');
require('dotenv').config()
const app = express();

// use dotenv file
host=process.env.HOST;
port=process.env.PORT;


const db = require('./config/mongoose');
const  Task  = require('./models/task');

app.use(express.static("./views"));

app.use(express.urlencoded());

// set up the view engine
app.set('view engine', 'ejs');
app.set('views', './views');


// rendering the App Page
app.get('/', function(req, res){
    Task.find({}, function(err, task){
        if(err){
            console.log('Error in fetching tasks from db');
            return;
        }

        return res.render('home', {
            tittle: "Home",
            task: task
        });
    }
)});


// creating Tasks
app.post('/create-task', function(req, res){
  
    
    Task.create({
        description: req.body.description,
        category: req.body.category,
        
        }, function(err, newtask){
        if(err){console.log('error in creating task', err); return;}
        
        return res.redirect('back');

    });
});


// deleting Tasks
app.get('/delete-task', function(req, res){
  
    var id = req.query;

    
    var count = Object.keys(id).length;
    for(let i=0; i < count ; i++){
        
        Task.findByIdAndDelete(Object.keys(id)[i], function(err){
        if(err){
            console.log('error in deleting task');
            }
        })
    }
    return res.redirect('back'); 
});


app.listen(port, function(err){
    if(err){
        console.log(`Error in running the server : ${err}`);
    }

    console.log(`Server is running on ${host}: ${port}`);
});